const jokes = {
  en: [
    "Why don’t scientists trust atoms? Because they make up everything!",
    "What do you call a bear with no teeth? A gummy bear!",
    "Why did the bicycle fall over? Because it was two-tired!"
  ],
  hi: [
    "पानी पीने के बाद मोबाइल क्यों नहीं चलता? क्योंकि वो वाटरप्रूफ नहीं है!",
    "टीचर: बताओ पंखा क्यों चलता है? छात्र: क्योंकि उसके पीछे पंख होते हैं!",
    "मोबाइल गुम हो गया... अब अलार्म कौन बजाएगा?"
  ]
};

let currentLang = 'en';

function loadJoke() {
  const list = jokes[currentLang];
  const randomIndex = Math.floor(Math.random() * list.length);
  document.getElementById("joke").textContent = list[randomIndex];
}

function playGame() {
  const msg = currentLang === 'hi' ? "आप जीत गए!" : "You won!";
  document.getElementById("game-result").textContent = msg;
}

function setLanguage(lang) {
  currentLang = lang;
  if (lang === 'hi') {
    document.getElementById("title").textContent = "स्वागत है FunZone में!";
    document.getElementById("subtitle").textContent = "बच्चे और बड़े, सबके लिए मज़ा!";
    document.getElementById("section1").textContent = "कार्टून टाइम!";
    document.getElementById("section2").textContent = "मजेदार जोक";
    document.getElementById("section3").textContent = "मिनी गेम";
    document.getElementById("section4").textContent = "वीडियो देखो और हँसो!";
    document.getElementById("footer").textContent = "बच्चों से लेकर बड़ों तक – सबके लिए बना प्यार से";
  } else {
    document.getElementById("title").textContent = "Welcome to FunZone!";
    document.getElementById("subtitle").textContent = "Kids and adults, enjoy jokes, games, cartoons and more!";
    document.getElementById("section1").textContent = "Cartoon Time!";
    document.getElementById("section2").textContent = "Funny Joke";
    document.getElementById("section3").textContent = "Mini Game";
    document.getElementById("section4").textContent = "Watch & Laugh!";
    document.getElementById("footer").textContent = "Made with fun for everyone – Kids to Adults";
  }
  loadJoke();
}

// Load first joke
loadJoke();
